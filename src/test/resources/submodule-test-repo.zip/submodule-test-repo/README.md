Repository with submodules to test changelog.
At different times contains
- no submodules
- library-a
- library-a and library-b
- library-b
