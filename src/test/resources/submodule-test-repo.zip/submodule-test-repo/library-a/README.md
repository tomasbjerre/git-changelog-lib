Repository that is used as a submodule.
